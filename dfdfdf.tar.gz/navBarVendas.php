<!-- Bootstrap core CSS -->
<link href="https://getbootstrap.com/docs/4.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">


    <style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        user-select: none;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }
    </style>
    <!-- Custom styles for this template -->
    <link href="css/starter-template.css" rel="stylesheet">
<!-- navbar navbar-expand-md navbar-dark bg-dark bg-primary-->
<!-- navbar navbar-dark bg-primary navbar-expand-md fixed-top-->
<nav class="navbar navbar-dark navbar-expand-md fixed-top" style="background-color: #2196F3;">
  <span class="_3PxOr"><img src="IMG/cropped-Logo-produtos-aqua-plus.png" height="42" width="42"> </span>
  <a class="navbar-brand" href="#"> AQUAPLUS DELIVERY</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
</nav>
