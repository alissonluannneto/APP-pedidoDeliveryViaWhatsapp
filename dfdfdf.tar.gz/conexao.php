<?php 

$conectar = mysqlI_connect("mysql.hostinger.com","u590376853_zap","@zap123456#","u590376853_siste") or die("erro conexão");

?>
